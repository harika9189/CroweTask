﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WriteMode
{
   // Use common design patterns(inheritance, e.g.) to account for these future concerns.
    public class DatabaseOutput : OutputWriter 
    {
        public override void Write(string message)
        {
            throw new NotImplementedException();
        }
    }
}
