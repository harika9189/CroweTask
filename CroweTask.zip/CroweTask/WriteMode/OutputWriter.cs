﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WriteMode
{
    public abstract class OutputWriter
    {
        public static OutputWriter GetOutputWriter(string WriteMode)
        {
            switch (WriteMode)
            {
                case "Console":
                    return new ConsoleOutput();
                case "Database":
                    return new DatabaseOutput();
                default:
                    return new ConsoleOutput(); // default Console

            }
        }
        public abstract void Write(string message);
    }
}
