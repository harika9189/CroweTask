﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiveAPI
{
    public class MobileService : IService
    {

        public string GetInfo()
        {
            throw new NotImplementedException();
        }
    }
}