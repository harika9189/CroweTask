﻿namespace ServiveAPI
{
    public interface IService
    {       
        string GetInfo();
    }
}


